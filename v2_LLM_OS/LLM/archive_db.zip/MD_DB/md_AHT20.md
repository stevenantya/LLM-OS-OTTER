##### ®
### AHT20 Product manuals
# ASAIR
###### Temperature and Humidity sensor

###### • Full calibration • Digital output, I C interface 2 • Excellent long-term stability • SMD package suitable for reflow soldering • Quick response and strong anti-jamming capability

3.0 1.1

2.0 0.7

0.8

0.4

|1.1 0.7|Col2|Col3|
|---|---|---|
||||
||||


|.0|3.0 2.0|1.0 0.4|
|---|---|---|
||0.55||



Buttom view Top view

Front view


Top view

Front view


Buttom view

|2.8±0.03mm|Col2|
|---|---|
|2.8±0.03mm|1.|
|||


Figure 1: AHT20 Sensor Package Diagram (Unit: mm  Tolerance: ±0.1 mm)

1.1


1/11


-----

AHT20 Product manuals

 - H(%RH) - ℃

±10

###### ®
## ASAIR


±8

±6

±4

±2

±0

|Col1|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||
|||||||||||||
|||||||||||||
||||||M|ax Valu|e|||||
|||||||||||||
|||||||||||||
|||||||||||||
|||||||||||||
|||||||||||||
|||||||||||||
|||||||||||||
|||||||||||||
|||||||||||||
|||||||||||||

0    10   20   30   40   50   60   70   80   90  100


±2.0

±1.5

±1.0

±0.5

±0.0

|℃|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|Col13|Col14|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||ue|||||
||||||||Typi|cal Val|ue|||||
|||||||||||||||
||||||||Ma|x Valu|e|||||
|||||||||||||||
|||||||||||||||
|||||||||||||||
|||||||||||||||
|||||||||||||||

-40     -20 0 20 40 60 80


1.1


2/11


-----

AHT20 Product manuals

###### ®
## ASAIR

The power consumption given in Table 1 is related to
temperature and supply voltage VDD. Estimated power
consumption, see Figures 6 and 7. Note that the curves
in Figures 6 and 7 are typical natural characteristics
and may have deviations.


1.1


3/11


-----

AHT20 Product manuals
###### 2.1 Welding Specification

The I/O pads of SMD are made of copper pin frame
planar substrates, which are exposed to the outside

for mechanical and electrical connections. When

used, I / O pads and bare pads need to be welded on
PCB. In order to prevent oxidation and optimize
welding, the welding joints at the bottom of the
sensor are plated with Ni/Au.On PCB, the length
of I/O contact surface should be 0.2 mm longer than 7
that of the I/O package pad of AHT 20. The inner part
should match the shape of the I/O package pad. The
ratio of pin width to SMD package pad width is1:1.
See figure 8.
For screen and solder layer design, it is suggested
to use copper foil definition solder (SMD) with the
solder layer opening larger than the metal solder
plate.
For SMD pads, if the gap between the copper
foil pad and the soldering layer is 60m-75m,
the opening size of the soldering layer shall be
greater than the size of the soldering plate
(120 m-150 m).
The circular part of the sealing pad shall match
the corresponding circular solder layer opening
to ensure that there is enough solder layer area
(especially at the corner) to prevent solder from
joining.
Each pad shall have its own soldering layer
opening, forming a soldering layer network 0.5 1.0

Top view 0.8

|Col1|Col2|2.0 acent pads.|Col4|Col5|Col6|Col7|
|---|---|---|---|---|---|---|
|||2.0|||||
||||||||
||||||||



For solder printing, laser cutting stainless steel mesh
with electronic polishing trapezoidal wall is
recommended, with recommended thickness of
0. 125 mm. The steel mesh size of the pad should be
0.1 mm longer than PCB pad and placed 0.1 mm away
from the packaging center. Steel mesh with bare pads
must cover 70% - 90% of the pad area - that is, the
central position of the heat dissipation area reaches
1. 4 mm x 2. 3 mm.

###### ®
## ASAIR

Due to the low SMD mounting, it is recommended to use
no-cleaning type 3 solders tin and to purify it with 9
nitrogen during reflux.

Preheating zone Time

AHT 20 can be welded through standard reflow furnace.
The sensor fully meets the IPC/JEDEC J-STD-020D
welding standard. The contact time should be less than
30 seconds at the highest 260℃ (see Fig. 9) and the
ultimate welding temperature that the sensor can
withstand is 260℃，so it is recommended to use low
temperature 180℃ when reflow soldering.

Note: After reflow welding, the sensor should be
stored in the environment of > 75% RH for at least
12 hours to ensure the re-hydration of the polymer.
Otherwise, it will cause sensor reading drift. The
sensor can also be placed in a natural environment
(> 40% RH) for more than five days to re-hydrate.
Hydration time can be reduced by using low
temperature reflow welding (e.g.180℃).

Don't wash the circuit boards is allowed after
welding. Therefore, it is suggested that customers
use "wash-free" solder paste. If the sensor is
applied to corrosive gases, condensate water may
be produced (e.g. in high humidity environment),
both pin pads and PCB need to be sealed
(e.g. using conformal coating) to avoid poor contact
or short circuit.

2.2 Storage conditions and instructions

The humidity sensitivity level (MSL) is 1, according
to IPC/JEDEC J-STD-020 standard. Therefore, it is
recommended to use it within one year after delivery.

Humidity sensor is not an ordinary electronic
component, and it needs careful protection, which
users must pay attention to. Long-term exposure
to high concentration of chemical vapor will cause
the sensor reading to drift.


1.1


4/11


-----

AHT20 Product manuals

Therefore, it is recommended that the sensor be
stored in the original package including sealed ESD
bag, and meet the following conditions: temperature
range 10~50℃（0~85℃ in a limited time), humidity
20~60% RH(no ESD packaged sensor). For sensors
that they be stored in antistatic bags made of metal
PET/AL/CPE.

During production and transportation, sensors should
avoid exposure to high concentration of chemical
solvents and prolonged exposure. Avoid exposure to
volatile glue, adhesive tape, stickers or volatile
packaging materials, such as foamed foil, foam
material, etc. The production area should be well
ventilated.
###### 2.3 Recovery processing

As mentioned above, if the sensor is exposed to
extreme working conditions or chemical vapor, the
reading will drift. It can be restored to the calibration
state by processing as follows. Drying: Keep for 10
hours at 80~85℃ with the humidity of more than 75%
RH.
Rehydration: Keep for 12 hours at 20~30 10 ℃ with the
humidity of more than 75% RH. 10  2.4 Temperature influence

The relative humidity of gases depends largely on
temperature. Therefore, when measuring humidity, all
sensors measuring the same humidity should work at
the same temperature as possible. When testing, it is
necessary to ensure that the same temperature, and
then compare the humidity readings.

If the sensor and the heating-prone electronic
components are placed on the same printing circuit
board, measures should be taken to minimize the
effect of heat transfer as far as possible in the design
of the circuit.
For example, to maintain good ventilation of the shell,
the copper coating of AHT20 and other parts of the
printed circuit board should be as smallest as
possible, or leave a gap between them. (See Fig. 10)

Moreover, when the measurement frequency is too
high, the temperature of the sensor itself will rise,
which will affect the measurement accuracy. In order
to make its temperature rise below 0.1�, the
activation time of AHT20 should not exceed 10% of

the measurement time - it is recommended to

measure data every 2 seconds.

###### ®
## ASAIR
###### 2.5 Product application scenario design

In product design, the sensor has following
characteristics:

1) Sensor is in full contact with the outside air

Housing

PCB

Figure 10: Suitable windows on the enclosure provide good
access to environmental measurements and allow for greater
air exchange.
2) The sensor is completely isolated from the
air nside the housing

Housing

PCB

Figure 12: The sensor is isolated from the air inside the housing,
which minimizes the impact of the air inside the housing on the

sensor.

3) Small measurement dead zone around the sensor

Housing

PCB

Figure 13: Small measurement dead zone helps the sensor to
quickly and comprehensively detect environmental changes.

4) The sensor is isolated from the heat

Figure 14: The sensor is isolated from the internal heat source to
minimize the effect of internal heat on sensor.

5) The sensor power supply can be controlled

In order to improve the stability of the system, the following two
solutions for controlling power supply are provided:

Figure 15-1 Typical application circuit ①, the pull-up voltage and
VDD of SCL and SDA are powered by the MCU.

Note: 1. The host MCU supplies AHT20 with a voltage range of 2.0
~ 5.5V.
2. When the AHT20 is just powered on, the MCU gives priority
to the VDD power supply, which can be set after 5ms SCL and SDA
are high.

Figure 15-2 Typical application circuit ②, AHT20 operation is
controlled by whether GND is grounded.

Note: The user can indirectly control the GND and ground by
controlling the switch module composed of transistors, so that the
AHT20 is powered off.


1.1


5/11


-----

###### ®
## AHT20 Product manuals ASAIR

###### 2.6 Material used for sealing and encapsulation

Many materials absorb moisture and act as buffer, which
will increase response time and hysteresis. Therefore, the
material around the sensor should be carefully seleaed.
Recommended materials are: Metal materials, LCP, POM
(Delrin). PTFE (Teflon), PE, PEEK, PP, PB, PPS, PSU,
PVDF, and PVF. Material for sealing and bonding
(conservative recommendation): It is recommended to use
method of flling epoxy resin or silicone resin for packaging
electronic components. Gases released from these
materials may also contaminate AHT20 (see 2.2).
Therefore. the sensor should be finally assembled and
placed in a well-ventilated place, or dried for 24 hours in
an environment of > 50℃, in order to release the
contaminated gas before packaging. 2.7 Wiring rules and signal integrity

If the SCL and SDA signal lines are parallel and very
close to each other, it may cause signal crosstalk and
communication failure. The solution is to place VDD
and / or GND between the two signal lines, separate
the signal lines, and use shielded cables. In addition,
reducing the SCL frequency may also improve the
integrity of signal transmission. A 100nF decoupling
capacitor must be added between the power supply
pins (VDD, GND) for filtering. This capacitor should be
as close as possible to the sensor. See the next chapter.

|Col1|Col2|Col3|NC 1 6 NC VDD 2 5 GND SCL 3 4 SDA Top view|
|---|---|---|---|
|||||
|||||
|||||
|||||
|||||
||||| 3.1 Power Pins (VDD,GND)

The power supply range of AHT20 is 2.0-5.5V, and the
recommended voltage is 3.3V. A decoupling capacitor
of 100nF must be added between VDD and GND to play
a filtering role. VDD is powered on preferentially or
synchronously than SDA and SCL to avoid the leakage
current from the signal line (SCL / SDA) sinking in,
causing the chip to be in a non-working state after

power-on.

###### 3.2 Serial clock SCL

SCL is used to synchronize the communication
between microprocessor and AHT20. Because the
interface contains complete static logic, there is no
minimum SCL frequency.  3.3 Serial data SDA

SDA pins are used for data input and output of sensors.
When sending commands to sensors, SDA is valid at
the rising edge of serial clock (SCL), and SDA must
remain stable when SCL is high level.After the
descending edge of SCL, the SDA value can be
changed. To ensure communication safety, the effective
time of SDA should be extended to TSU and THO
respectively before SCL rising edge and after SCL
falling edge-refer to Fig 17. When the data is read from
the sensor, SDA is valid (TV) after the SCL decreases
and maintains the descent edge of the next SCL.

Figure 16 Typical application circuit

Note: 1. The pull-up voltage of SCL and SDA must be powered by VDD,
and the power supply voltage range is 2.0 ~ 5.5V;
2. Add 100nF decoupling capacitor between VDD and GND;
3. AHT20 can share I2C bus with other I2C devices.

To avoid signal collision, MCU must only drive SDA and
SCL at low levels. An external pull-up resistor(e.g.10kΩ)
is needed to lift the signal to a high level. The pull-up
resistance may have been included in the MCU's I/O
circuit. Detailed information about sensor input/output
characteristics can be obtained by referring to tables 7
and 8. 4.1 Absolute Maximum Rating

The electric specifcations of AHT20 are defned in
Table 2. The absolute maximum ratings given in Table 6
are only stress ratings and to provide more information.
Under such conditions, it is not advisable for the device
to perform functional operation. Exposure to absolute
maximum rating or a long time may affect the reliability
of the sensor.

1.1 6/11


-----

AHT20 Product manuals

ESD electrostatic discharge conforms to JEDEC
JESD22-A114 standard (human body mode ±4kV) and
JEDEC JESD22-A115 (machine mode±200V) If the test
condition exceeds the nominal limit, the sensor needs
additional protection circuit.
###### 4.2 Input/output characteristics

Electric specifcations include power consumption, high
and low voltage of input and output, voltage of power
supply. In order to make the sensor communication
smooth, it is important to ensure that the signal design
is strictly limited to the range given in tables 7, 8 and 17.

###### ®
## ASAIR

AHT20 adopts standard I²C protocol to communicate.
For information on the I²C protocol except the
following chapters, please refer to the following
website: www.aosong.com for sample reference.
###### 5.1 Start Sensor

Step 1: Make the sensor power on with selected voltage
of VDD power supply voltage (ranging from 2.0V to 5.5V).
When the sensor is powered on, it takes 20 milliseconds
at most (the SCL is high level) to enter idle state, thatis, to
be ready to receive commands sent by MCU. 5.2 Timing sequence of start/stop

Each transport sequence starts with the Start state
and ends with the Stop state, as shown in Figures
18 and 19.

1.1 7/11


-----

AHT20 Product manuals
###### 5.3 Send Command



After the transmission is initiated, the first byte of the
subsequent I2C transmission includes the 7-bit I2C
device address 0x38 and a SDA direction bit x (read R:
‘1’, write W: ‘0’). After the falling edge of the 8th SCL
clock, the SDA pin (ACK) is pulled low to indicate that
the sensor data reception is normal. After issuing the
initialization command 0xBE and the measurement
command 0xAC, the MCU must wait until the
measurement is completed. The basic commands are
summarized in Table 9. Table 10 shows the status bits

returned from the slave.

###### ®
## ASAIR
###### 5.4 Sensor reading process

1. Wait 40ms after power-on. Before reading the temperature
and humidity values, first check whether the calibration
enable bit Bit [3] of the status word is 1 (you can get a byte of
status word by sending 0x71). If not 1, need to send 0xbe
command (for initialization), this command parameter has
two bytes, the first byte is 0x08, the second byte is 0x00,
and then wait for 10ms.

2. Send the 0xAC command directly (trigger measurement).
The parameter of this command has two bytes, the first byte
is 0x33 and the second byte is 0x00.

3. Wait for 80ms to wait for the measurement to be completed.
If the read status word Bit [7] is 0, it indicates that the
measurement is completed, and then six bytes can be read
in a row; otherwise, continue to wait.

4. After receiving six bytes, the next byte is the CRC check
data, the user can read it as needed, if the receiving end
needs CRC check, then send it after receiving the sixth byte
ACK response, otherwise NACK is sent out, CRC initial value
is 0XFF, CRC8 check polynomial is:  CRC[7:0]=1+x + x + x 4 5 8

5. Calculate the temperature and humidity values.

Note: The calibration status check in the first step
only needs to be checked at power-on. No operation
is required during the normal acquisition process.

Trigger measurement data

|Col1|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|Col13|Col14|Col15|Col16|Col17|Col18|Col19|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||I²C address + write|||||||||Trigger measurement 0xAC|||||||||


|Col1|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|Col13|Col14|Col15|Col16|Col17|Col18|Col19|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|DATA0|||||||||DATA0||||||||||



Read temperature and humidity data

NACK

|Col1|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|Col13|Col14|Col15|Col16|Col17|Col18|Col19|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||I²C address + read|||||||||State|||||||||


|Col1|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|Col13|Col14|Col15|Col16|Col17|Col18|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Humidity data|||||||||Humidity data|||||||||


|Col1|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|Col13|Col14|Col15|Col16|Col17|Col18|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Humidity temperature|||||||||Temperature data|||||||||


|Col1|Col2|Col3|Col4|Col5|Col6|Col7|Col8|Col9|Col10|Col11|Col12|Col13|Col14|Col15|Col16|Col17|Col18|Col19|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Temperature data|||||||||CRC data||||||||||



1.1 8/11

|Col1|Col2|Col3|
|---|---|---|
||||
||||
||||
||||
|[2:0]|||


-----

AHT20 Product manuals
###### 5.5 Soft Reset

This command (see Table 11) is used to restart the sensor
system without turning the power off and on again. After
receiving this command, the sensor system begins to
re-initialize and restore the default setting state, and the
time required for soft reset does not exceed 20 ms.

Table 11 Soft Reset– The grey part is controlled by AHT20. 6.1 Relative humidity transformation

Relative humidity RH can be calculated according to
the relative humidity signal SRH output from SDA by
the following equation.
(The result is expressed in% RH) 6.2 Temperature transformation

Temperature T can be calculated by substituting the
temperature output signal ST into the following formula.
(The results are expressed as temperature ℃ T)

If the sensor is used in equipment or machinery，please
make sure that it is the same temperature and humidity
that the sensor used for measurement and the sensor

used for reference that have sensed. If the sensor is
placed in the equipment, the reaction time will be
prolonged, so it is necessary to ensure that suffcient
measurement time is reserved in the programming.
The AHT20 sensor is tested according to the enterprise
standard of Aosong temperature and humidity sensor.
The performance of sensors under other test conditions
is not guaranteed and cannot be regarded as a part of
sensor performance. Especially for the specific
occasions required by users, we do not make any
commitments.

###### ®
## ASAIR

AHT20 provides SMD packaging (similar to QFN),
which represents a bilateral flat and pin-free package.
The sensor chip is made of a copper lead frame coated
with Ni/Au. The weight of the sensor is about 19 mg.

All AHT20 sensors have laser labels on their surfaces.
See Figure 20.

Figure 20: Sensor laser label

A label is also attached to the tape, as shown in Figure 21,
and other trace information is provided.
###### ®
#### ASAIR

名称: 温湿度传感器
Name

型号: AHT20
Model

数量: 5000PCS
Quantity

日期: YYYY-MM-DD
Date

批号: XXXXXX
Batch number

2 0 1 9 1 2 1 0

Figure 21: Label on the tape

1.1 9/11


-----

AHT20 Product manuals

13.5±0.5mm

93.0±1mm

A1±1mm

I

B W

K

P1 D

###### ®
## ASAIR

|Date|Version|Page C|hange|
|---|---|---|---|
|2019/12|V1.0|1-10 In|itial version|
|2020/04|V1.1|A 1-11 d|dd CRC check description, modify application scenario esign and read process description|


1.1 10/11

|W1|Col2|
|---|---|
|||
|||
|W2||


A

###### N

W1

W2

|Col1|Col2|Col3|
|---|---|---|
||||
||||



φR1


|F|Col2|Col3|Col4|Col5|Col6|Col7|
|---|---|---|---|---|---|---|
|E|||||||
||||||||

|Model|A1|Col3|E|W1|Col6|W2|N|Col9|
|---|---|---|---|---|---|---|---|---|
|AHT20|233/330||2|12||16|100||
||||||||||
|Model|Unit|Tolerance|||Quantity|||Weight|
|AHT20|mm|±0.5|||5000(AMX)|||500/g|


|Model|A/B|K|W|φR2/φR3|φR1|
|---|---|---|---|---|---|
|AHT20|3.25+ -0 0. .1 0|1.25+ -0 0. .1 0|12.0±0.3|1.50+ -0 0. .1 0|0.50+ -0 0. .|

|Model|P1|P2|I|F|E|D|
|---|---|---|---|---|---|---|
|AHT20|8.0±0.1|4.0±0.1|0.3±0.05|5.5±0.1|1.75±0.|1 2.0±0.1|


Figure 22: Package tape and sensor location diagram
###### Version information

This manual is subject to change without notice.


-----

AHT20 Product manuals
##### Attention


®

###### ®
## ASAIR

11/11


1.1


-----

